#!/bin/bash

echo "do post remove..."
