#!/bin/bash

echo "do prepare build..."

