#ifndef __GSGPU_PM_H__
#define __GSGPU_PM_H__

int gsgpu_pm_sysfs_init(struct gsgpu_device *adev);

#endif
