/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2020-2022 Loongson Technology Corporation Limited
 */

#ifndef __GSGPU_XDMA_H__
#define __GSGPU_XDMA_H__

extern const struct gsgpu_ip_block_version xdma_ip_block;

#endif /*__GSGPU_XDMA_H__*/
